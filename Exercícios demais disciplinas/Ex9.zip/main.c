#include <stdio.h>
int main (){
float areat, baset, alturat;
printf("Digite o valor da base do triângulo\n");
  scanf("%f%*c", &baset);
  printf("Digite o valor da altura do triângulo\n");
  scanf("%f%*c", &alturat);
  areat=(baset*alturat)/2;
printf("O valor da área de triângulo é:%.2f", areat);  
  return 0;

  }