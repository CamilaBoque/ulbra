#include <stdio.h>
int main() {
float sal, novosal;
printf("Digite o valor do salário atual:\n");
scanf("%f%*c",&sal);
novosal=sal+sal*25/100;
printf("O novo salário é igual a R$:%.2f", novosal);
return 0;
  }


