#include <stdio.h>
int main (){
float nt1, nt2, nt3;
  printf("Digite o valor de nt1:\n");
scanf("%f%*c",&nt1);
  printf("Digite o valor de nt2:\n");
scanf("%f%*c",&nt2);
  printf("Digite o valor de nt3:\n");
scanf("%f%*c",&nt3);
  float media=(nt1+nt2+nt3)/3;
  printf("A média é igual:%.2f", media);
  return 0;
  
  
}