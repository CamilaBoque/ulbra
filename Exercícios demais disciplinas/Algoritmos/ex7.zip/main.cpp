#include <stdio.h>
int main (){
float sal, imp, salarec;
printf("Digite o valor do salário base\n");
  scanf("%f%*c", &sal);
  imp=sal*10/100;
  salarec=sal+50-imp;
printf("O valor do salário a receber é:%.2f", salarec);  
  return 0;

  }