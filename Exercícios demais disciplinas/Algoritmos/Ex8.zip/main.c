#include <stdio.h>
int main (){
float vdep, taxa, valrend, valfinal;
printf("Digite o valor do depósito\n");
  scanf("%f%*c", &vdep);
  printf("Digite o valor da taxa\n");
  scanf("%f%*c", &taxa);
  valrend=vdep*taxa/100;
  valfinal=vdep+valrend;
printf("O valor da renda é:%.2f\n", valrend);  
  printf("O valor final é:%.2f\n", valfinal);
  return 0;

  }