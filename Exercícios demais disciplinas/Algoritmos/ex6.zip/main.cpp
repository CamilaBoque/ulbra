#include <stdio.h>
int main (){
float sal, insal, imp, salf;
  printf("Digite o valor do salário atual:\n");
  scanf("%f%*c",&sal);
  insal=sal*5/100;
  imp=sal*7/100;
  salf=sal+insal-imp;  
  printf("O valor do novo salário é:%.2f", salf);  
  return 0;
}