#include <stdio.h>
int main (){
float sal, perc, vlaum, novsal;
  printf("Digite o valor do salário atual:\n");
  scanf("%f%*c",&sal);
  printf("Digite o percentual de aumento:\n");
  scanf("%f%*c",&perc);
  vlaum=sal*perc/100;
  printf("O valor do aumento é :%.2f\n", vlaum);  
  novsal=sal+vlaum;  
  printf("O valor do novo salário é:%.2f", novsal);  
  return 0;
}
