#include <stdio.h>
 main (){
float area, raio, pi;
printf("Digite o valor do raio do círculo\n");
  scanf("%f%*c", &raio);
 pi=3,1415;
area=pi*(raio*raio);
printf("O valor da área do círculo é:%.2f\n", area);  
  return 0;

  }