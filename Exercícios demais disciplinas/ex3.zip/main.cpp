#include <stdio.h>>

int main() {
float nt1,nt2,nt3,ps1,ps2,ps3,media;
  printf("Digite o valor de nt1:\n");
scanf("%f%*c",&nt1);
  printf("Digite o valor de nt2:\n");
scanf("%f%*c",&nt2);
  printf("Digite o valor de nt3:\n");
scanf("%f%*c",&nt3);
   printf("Digite o valor de ps1:\n");
scanf("%f%*c",&ps1);
  printf("Digite o valor de ps2:\n");
scanf("%f%*c",&ps2);
  printf("Digite o valor de ps3:\n");
scanf("%f%*c",&ps3);
media=(nt1*ps1+nt2*ps2+nt3*ps3)/(ps1+ps2+ps3);
  printf("A média ponderada é igual a:%.2f", media);
  return 0;
  
  
}