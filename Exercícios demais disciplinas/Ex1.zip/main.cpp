#include <stdio.h>
int main(){  
 float n1,n2,n3,n4;
 printf("Digite o valor de n1:\n");
scanf("%f%*c",&n1);
  printf("Digite o valor de n2:\n");
scanf("%f%*c",&n2);
  printf("Digite o valor de n3:\n");
scanf("%f%*c",&n3);
  printf("Digite o valor de n4:\n");
scanf("%f%*c",&n4);  
  float soma=n1+n2+n3+n4;
  printf("Soma= %.2f", soma);  
  return 0;
}